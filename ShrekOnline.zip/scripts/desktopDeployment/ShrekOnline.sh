#!/bin/bash
jre/bin/java -XX:MaxRAMPercentage=60 -classpath "lib/*" org.amogustechnologies.ShrekOnline
exit 0
